<?php
session_start();
include '../src/components.php';
include '../src/conf.php';

$error = '';
$sql = "SELECT * FROM f_products";
$rec = $baza->query($sql);

$products = [];
while($r = $rec->fetch_assoc()){
    $products[] = $r;
}

$sql = "SELECT * FROM f_category";
$rec = $baza->query($sql);

$category = [];
while($r = $rec->fetch_assoc()){
    $category[] = $r;
}

$id = 0;
if (isset($_GET['id'])){
    $id = $_GET['id'];
    
    $sql = "SELECT * FROM `f_products` WHERE id=$id";
    $product = $baza->query($sql)->fetch_assoc();
}
?>
<html>
<?=head('Products', '../')?>
<body>
    <div class="header">
        <div class="navbar">
            <div class="logo">FarmLink</div>
            <div class="links">
                <a href="orders">Cabinet</a>    
            </div>
        </div>
    </div>
    
    <?php
    
    if ($id == 0){
        
    ?>

    <div class="main">
        <div class="categories">
            <?php
                foreach ($category as $v){
                    echo '<a href="#" class="category">
                    <div class="img">
                        <img src="../img/watermelon.jpg">
                    </div>
                    <div class="name">
                        '.$v['name'].'
                    </div>
                </a>';
                }
            ?>
        </div>
        <div class="cards">
            <?php
            
            foreach ($products as $v){
                echo '<div class="card">
                <a href="?id='.$v['id'].'">
                    <div class="img">
                        <img src="../img/'.$v['image'].'">
                    </div>
                    <div class="info">
                        <div class="name">
                            '.$v['name'].'
                        </div>
                        <div class="price">
                            '.number_format($v['price'], 0, ' ', ' ').' sum
                        </div>
                        <div class="address">
                            '.$v['region'].', '.$v['district'].'
                        </div>
                    </div>
                </a>
            </div>';
            }
            
            ?>
        </div>
    </div>
    
    <?php
        
    } elseif ($id > 0){
        
        ?>
        
    <div class="main">
        <?=$error?>
        <div class="product">
            <div class="img">
                <img src="../img/<?=$product['image']?>">
            </div>
            <div class="name">
            <?=$product['name']?>
            </div>
            <div class="price">
                <?=number_format($product['price'], 0, ' ', ' ')?> sum / <?=$product['birligi']?>
            </div>
            <div class="info">
            <?=$product['info']?>
            </div>
            <div class="address">
                <?=$product['region'].', '.$product['district']?>
            </div>
            <div class="phone">
                +998994442252
            </div>
            <div class="buy">
                <h3>Buy</h3>
                <form method="post" action="orders">
                    <input type="number" name="count" placeholder="count" required>
                    <input type="hidden" name="id" value="<?=$product['id']?>">
                    <input type="submit" name="buy" value="Buy">
                </form>
            </div>
        </div>
    </div>
        
    <?php
        
    }
    
    ?>
</body>