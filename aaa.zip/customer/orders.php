<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);


session_start();
include '../src/components.php';
include '../src/conf.php';


$user_id = $_SESSION['user_id'];
if ($_SESSION['role'] != 'customer'){
    header('Location: ../auth');
    exit;
}
if (isset($_POST['buy'])){
    $id = $_POST['id'];
    $count = $_POST['count'];
    
    $sql = "SELECT * FROM `f_products` WHERE id=$id";
    $product = $baza->query($sql)->fetch_assoc();
    
    $seller_id = $product['user_id'];
    $product_price = $product['price'];
    $summ = $product_price * $count;
    
    $sql = "INSERT INTO `f_orders`(customer_id, seller_id, product_id, amout, product_price, summ, status)
    VALUES
    ($user_id, $seller_id, $id, $count, $product_price, $summ, 'progressing')";
    
    $baza->query($sql);
    
    header('Location: orders');
}

if (isset($_GET['t'])){
    $type = $_GET['t'];
} else {
    $type = '';
}

$sql = "SELECT * FROM `f_orders` WHERE customer_id=$user_id ORDER BY id DESC";
$rec = $baza->query($sql);

$orders = [];
while($r = $rec->fetch_assoc()){
   $orders[] = $r; 
}

?>
<html>
<?=head('FarmLink - Cabinet', '../')?>
<body>
    <?=sellerheader()?>
    <div class="seller">
        <?=leftnavbarc('orders')?>
        <div class="main">
        
            <div class="product">
                <div class="img">
                    <img src="../img/watermelon.jpg">
                </div>
                <div class="info">
                vfibvfshbvfsbbfsbvfsibsfbbvfsibvisufbvsfiuv sfvfsbvfsibvsfvsufiv sufvfsv sfivsfvfsv fsuvbf fvbsfbv vbfsv sbv
                </div>
                <div class="address">
                <span class="material-symbols-outlined">location_on</span>Tashkent > Chilanzar
                </div>
            </div>            
            
            <?php
            
            if ($type == 'acc'){
                $id = $_GET['id'];
                
                //buyurtma haqida malumot olish
                $sql = "SELECT * FROM `f_orders` WHERE id=$id";
                $order = $baza->query($sql)->fetch_assoc();
                
                //buyurtma statusini o'zgartrish
                $sql = "UPDATE `f_orders` SET status='successful' WHERE id=$id";
                $baza->query($sql);
                
                //pulni savdogarga o'tkazib berish
                $amout = $order['summ'];
                $seller_id = $order['seller_id'];
                $sql = "INSERT INTO f_transaction(user_id, amout, type, order_id) VALUES ($seller_id, $amout, 'buy', $id)";
                $baza->query($sql);
                
                //savdogarga muzlatilgan pulni qaytarish
                $sql = "SELECT * FROM `f_frozen` WHERE order_id=$id";
                $frozen = $baza->query($sql)->fetch_assoc();
                $amout = $frozen['amout'];
                $sql = "INSERT INTO f_transaction(user_id, amout, type, order_id) VALUES ($seller_id, $amout, 'frozen', $id)";
                $baza->query($sql);
                
                header('Location: orders');
            } elseif ($type == 'can') {
                $id = $_GET['id'];
                
                $sql = "UPDATE `f_orders` SET status='notaccepted' WHERE id=$id";
                $baza->query($sql);
                
                header('Location: orders');
            }
            
            ?>
            
            <div class="orders">
                <div class="tr-table">
                    <table>
                        <tr>
                            <th>Date</th>
                            <th>Status</th>
                            <th>Amout</th>
                            <th>Order Id</th>
                            <td>Action</td>
                        </tr>
                        
                        <?php
                        
                        foreach ($orders as $v){
                            $id = $v['id'];
                            if ($v['status'] == 'inprogress'){
                                $action = '<a href="?id='.$id.'&t=acc">Received</a> | <a href="?id='.$id.'&t=can">No Received</a>';
                            } else {
                                $action = '';
                            }
                            
                            echo '<tr>
                                <td>'.$v['date'].'</td>
                                <td>'.$v['status'].'</td>
                                <td>'.$v['summ'].'</td>
                                <td><a href="#">'.$id.'</a></td>
                                <td>'.$action.'</td>
                            </tr>';
                        }
                        
                        ?>
                    </table>
                </div>
            </div>
            
        </div>
    </div>
</body>