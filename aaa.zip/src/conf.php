<?php
$servernomi_db = 'localhost';
$usernomi_db = 'x_u_7208_bek';
$parol_db = 'DrebNBx2aKv2y_w';
$dbnomi_db = 'x_u_7208_bek';
$baza = new mysqli($servernomi_db, $usernomi_db, $parol_db, $dbnomi_db);
?>